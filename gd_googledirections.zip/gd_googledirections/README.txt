=======================================================================
GoogleDirections - TYPOlight modul
Author: Claude Gex <mail@claudegex.ch>
=======================================================================

This Module allows you to integrate Google's route planner functionality
into your website. Some of the code was taken or inspired by the module
dlh_googlemaps from Christian de la Haye.
=======================================================================
GoogleDirections - Contao module
Author: Claude Gex <mail@claudegex.ch>
=======================================================================

This module allows you to integrate Google's route planner functionality
into your website.